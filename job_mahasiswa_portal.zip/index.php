<?php
include "koneksi.php"; 

$sql = "SELECT * FROM jobs ORDER BY id DESC";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Job Mahasiswa - Portal</title>
    <style>
        .job-card {
            border: 1px solid #ccc;
            padding: 15px;
            margin: 10px 0;
            border-radius: 10px;
        }
        .apply-btn {
            background: green;
            color: white;
            padding: 8px 12px;
            text-decoration: none;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <h1>Job Mahasiswa - Portal</h1>
    <a href="post_job.php">+ Post Job Baru</a>
    <hr>

    <?php while ($row = mysqli_fetch_assoc($result)) { ?>
        <div class="job-card">
            <h3><?php echo $row['judul']; ?></h3>
            <small>Poster: <?php echo $row['email']; ?> | 
                   Gaji: Rp <?php echo $row['gaji']; ?> | 
                   <?php echo strtoupper($row['kategori']); ?>
            </small>
            <p><?php echo $row['laporan']; ?></p>
            <p>No. HP: <?php echo $row['nohp']; ?></p>
            <p>No. WhatsApp: <?php echo $row['whatsapp']; ?></p>
            <p>Email Kontak: <?php echo $row['email_contact']; ?></p>
            <p>Pembayaran via E-Wallet: <?php echo $row['ewallet']; ?></p>
            <a class="apply-btn" href="#">Apply</a>
        </div>
    <?php } ?>
</body>
</html>